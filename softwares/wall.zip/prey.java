import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Basic Controlled character
 * 
 * @author Scott Turner 
 * @version 1.0
 */
public class prey  extends Actor
{
    
  
    public prey()
    {
        
    }
    
    
    public void act() 
    {

       //Start of section of code you change
       forward(100);
       turnRight(135);
       forward(140);
       turnRight(45);
       backward(100);
       //End of section of code you change 
       
       
        //NO NEED TO CHANGE THE CODE BELOW FOR BASIC USAGE 
        Greenfoot.stop();

    } 
    
    
    
    
    
    
    //NO NEED TO CHANGE THE CODE BELOW FOR BASIC USAGE
    
    
    
    
    
    public void turnLeft(int degree)
    {
       turn(-1*degree);
       waitForIt();
    }
    public void turnRight(int degree)
    {
        turn(degree);
        waitForIt();
    }
    public void forward(int step)
    {
        move(step);
        waitForIt();
    }
     public void backward(int step)
     {
         move(-1*step);
         waitForIt();
     }
     public void waitForIt()
     {
         Greenfoot.delay(1);
     }
     
     public boolean leftBumper()
     {
         List<wall> bumps=getIntersectingObjects(wall.class);
         boolean flag=false;
         int bx=0;
         int by=0;
         
         if (bumps != null)
         {
             int rot_pos=getRotation();
             for (wall blocks: bumps)
             {
                 bx=blocks.getX();
                 by=blocks.getY();
                 if (((rot_pos>331)||(rot_pos<30))&&((getX()-bx)<0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>60)||(rot_pos<120))&&((getX()-bx)<0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>150)||(rot_pos<210))&&((getX()-bx)>=0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>240)||(rot_pos<300))&&((getX()-bx)>=0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
             }
         }
         return flag;
        }
             public boolean rightBumper()
     {
         List<wall> bumps=getIntersectingObjects(wall.class);
         boolean flag=false;
         int bx=0;
         int by=0;
         
         if (bumps != null)
         {
             int rot_pos=getRotation();
             for (wall blocks: bumps)
             {
                 bx=blocks.getX();
                 by=blocks.getY();
                 if (((rot_pos>331)||(rot_pos<30))&&((getX()-bx)<0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>60)||(rot_pos<120))&&((getX()-bx)>0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>150)||(rot_pos<210))&&((getX()-bx)>=0)&&((getY()-by)>0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>240)||(rot_pos<300))&&((getX()-bx)<0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
             }
         }
         return flag;
        }
                public boolean checkBumpers()
        {
            boolean bumpit=false;
            if ((leftBumper()==true)&&(rightBumper()==true))
            {
                bumpit=true;
            }
            return bumpit;
        }
}

