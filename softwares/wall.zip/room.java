import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class room here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class room  extends World
{

    /**
     * Constructor for objects of class room.
     * 
     */
    public room()
    {    
        // Create a new world with 20x20 cells with a cell size of 10x10 pixels.
        super(600, 400, 1); 
        for (int loop=0;loop<=575; loop=loop+25)
        {
            addObject(new wall(), loop, 10);
            addObject(new wall(), loop, 390);
            
        }
        for (int loop_v=20;loop_v<=380; loop_v=loop_v+15)
        {
            addObject(new wall(), 10, loop_v);
            addObject(new wall(), 580,loop_v);
            
        }
        addObject(new prey(), 100,100);
    }
}
