import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class prey here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class prey  extends Actor
{
    
  
    public prey()
    {
        setLocation(100,100);
        
    }
    
    
    public void act() 
    {

        if (checkBumpers()==true)
        {
            //What do you do if there is a wall in front
        }
        else
        {
           //What do you do if there isn't a wall in front of it.
        }
        
        
        
        //Greenfoot.stop();

    } 
    public void turnLeft(int degree)
    {
       turn(-1*degree);
       waitForIt();
    }
    public void turnRight(int degree)
    {
        turn(degree);
        waitForIt();
    }
    public void forward(int step)
    {
        move(step);
        waitForIt();
    }
     public void backward(int step)
     {
         move(-1*step);
         waitForIt();
     }
     public void waitForIt()
     {
         Greenfoot.delay(1);
     }
     
     public boolean leftBumper()
     {
         List<wall> bumps=getIntersectingObjects(wall.class);
         boolean flag=false;
         int bx=0;
         int by=0;
         
         if (bumps != null)
         {
             int rot_pos=getRotation();
             for (wall blocks: bumps)
             {
                 bx=blocks.getX();
                 by=blocks.getY();
                 if (((rot_pos>331)||(rot_pos<30))&&((getX()-bx)<0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>60)||(rot_pos<120))&&((getX()-bx)<0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>150)||(rot_pos<210))&&((getX()-bx)>=0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>240)||(rot_pos<300))&&((getX()-bx)>=0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
             }
         }
         return flag;
        }
             public boolean rightBumper()
     {
         List<wall> bumps=getIntersectingObjects(wall.class);
         boolean flag=false;
         int bx=0;
         int by=0;
         
         if (bumps != null)
         {
             int rot_pos=getRotation();
             for (wall blocks: bumps)
             {
                 bx=blocks.getX();
                 by=blocks.getY();
                 if (((rot_pos>331)||(rot_pos<30))&&((getX()-bx)<0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>60)||(rot_pos<120))&&((getX()-bx)>0)&&((getY()-by)<0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>150)||(rot_pos<210))&&((getX()-bx)>=0)&&((getY()-by)>0))
                 {
                     flag=true;
                 }
                 if (((rot_pos>240)||(rot_pos<300))&&((getX()-bx)<0)&&((getY()-by)>=0))
                 {
                     flag=true;
                 }
             }
         }
         return flag;
        }
        public boolean checkBumpers()
        {
            boolean bumpit=false;
            if ((leftBumper()==true)&&(rightBumper()==true))
            {
                bumpit=true;
            }
            return bumpit;
        }
}

